Power BI Dashboard Pack (Bank Churn)

What you get
- Cleaned dataset: bank_churn_clean.csv
- KPI tables for visuals: kpi_overall.csv, kpi_by_geography.csv, kpi_by_gender.csv, kpi_by_products.csv, kpi_by_activity.csv
- Pre-rendered visuals as PNGs (optional to use directly)
- Suggested DAX measures below

Recommended Power BI pages
Page 1: Executive Summary
- KPI Cards: Customers, Churned, Churn Rate, Avg Age, Avg Balance
- Churn rate by Geography (bar)
- Churn rate by Gender (bar)
- Churn rate by Activity (bar)

Page 2: Drivers
- Churn rate by Age band and Geography (line)
- Churn rate by Number of Products (line)
- Correlation with churn (bar)

Suggested DAX measures (assuming table name is BankChurn)
Customers = COUNTROWS(BankChurn)
Churned = CALCULATE(COUNTROWS(BankChurn), BankChurn[Exited] = 1)
Churn Rate = DIVIDE([Churned], [Customers])
Active Member % = AVERAGE(BankChurn[IsActiveMember])
Has Credit Card % = AVERAGE(BankChurn[HasCrCard])
Avg Age = AVERAGE(BankChurn[Age])
Avg Balance = AVERAGE(BankChurn[Balance])

Tips
- Use slicers for Geography, Gender, IsActiveMember, NumOfProducts, Age (or AgeBin)
- Set AgeBinLabel sort order by creating a numeric sort column in Power BI if needed
